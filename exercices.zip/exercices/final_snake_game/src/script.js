/* global window document */
import Game from "./game";

window.onload = () => {
  document.onkeydown = e => {
    const key = e.keyCode;
    let newDirection;
    switch (key) {
      case 37:
        newDirection = "left";
        break;
      case 38:
        newDirection = "up";
        break;
      case 39:
        newDirection = "right";
        break;
      case 40:
        newDirection = "down";
        break;
      case 32:
        myGame.launch();
        return;
      default:
        return;
    }
    myGame.snakee.setDirection(newDirection);
  };

  let myGame = new Game();
  myGame.init();
};
